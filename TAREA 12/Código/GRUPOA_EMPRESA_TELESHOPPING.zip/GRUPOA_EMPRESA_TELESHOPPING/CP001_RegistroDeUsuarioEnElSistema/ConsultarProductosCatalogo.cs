﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using NUnit.Framework;

namespace Pruebas
{
    [TestFixture]
    public class ConsultarProductosCatalogo
    {
        [Test]
        public void ConsultarProductosEnCatalogoExitoso()
        {
            CN_Productos productos = new CN_Productos();

            string nombreProductoABuscar = "Camiseta";

            DataTable resultado = productos.BuscarProductosPorNombre(nombreProductoABuscar);

            Assert.IsNotNull(resultado, "La búsqueda de productos debería ser exitosa.");

            if (resultado.Rows.Count > 0)
            {
                // Se encontraron productos, verificar si alguno coincide con el nombre buscado
                bool productoEncontrado = false;
                foreach (DataRow row in resultado.Rows)
                {
                    string? nombreProducto = row["Nombre"].ToString();
                    if (nombreProducto.Equals(nombreProductoABuscar, StringComparison.OrdinalIgnoreCase))
                    {
                        productoEncontrado = true;
                        break;
                    }
                }

                Assert.IsTrue(productoEncontrado, "El sistema debería mostrar el producto buscado.");
            }
            else
            {
                // No se encontraron productos, también es una opción válida
                Console.WriteLine("No se encontraron productos con el nombre: " + nombreProductoABuscar);
            }
        }
    }
}
