﻿
using System;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class ModulosD
    {
        private string connectionString; // Cadena de conexión a la base de datos

        /// <summary>
        /// Constructor de la clase ModulosD.
        /// </summary>
        /// <param name="connectionString">Cadena de conexión a la base de datos.</param>
        public ModulosD(string connectionString)
        {
            this.connectionString = connectionString;
        }

        /// <summary>
        /// Obtiene el nombre y apellido de un usuario en base a su número de cédula.
        /// </summary>
        /// <param name="ci">Número de cédula del usuario.</param>
        /// <returns>Nombre y apellido del usuario.</returns>
        public string ObtenerNombreYApellido(string ci)
        {
            string nombreApellido = "";

            // Realizar la conexión con la base de datos
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Construir la consulta SQL
                string query = "ObtenerNombreYApellido";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Especificar que se ejecutará un procedimiento almacenado
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    // Asignar el parámetro CI a la consulta SQL
                    command.Parameters.AddWithValue("@ci", ci);

                    connection.Open();

                    // Ejecutar la consulta y obtener el resultado
                    object resultado = command.ExecuteScalar();

                    if (resultado != null)
                    {
                        nombreApellido = resultado.ToString();
                    }
                }
            }

            return nombreApellido;
        }
    }
}
