﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    /// <summary>
    /// Clase parcial que representa el formulario principal del usuario con rol de administrador.
    /// </summary>
    public partial class FrmADMIN : Form
    {
        /// <summary>
        /// Constructor de la clase FrmADMIN.
        /// </summary>
        public FrmADMIN()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Manejador de eventos para el clic en el menú "Catálogo de Productos".
        /// </summary>
        private void catalogoDeProductosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario FrmInsertarProductosADMI
            FrmInsertarProductosADMI frmproductos = new FrmInsertarProductosADMI();

            // Establece el formulario FrmInsertarProductosADMI como formulario secundario
            frmproductos.MdiParent = this;

            // Lleva el formulario FrmInsertarProductosADMI al frente
            frmproductos.BringToFront();

            // Muestra el formulario FrmInsertarProductosADMI
            frmproductos.Show();
        }

        /// <summary>
        /// Manejador de eventos para el clic en el menú "Envíos".
        /// </summary>
        private void enviosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario FrmEnvioADMIN
            FrmEnvioADMIN frmEnvioADMIN = new FrmEnvioADMIN();

            // Establece el formulario FrmEnvioADMIN como formulario secundario
            frmEnvioADMIN.MdiParent = this;

            // Lleva el formulario FrmEnvioADMIN al frente
            frmEnvioADMIN.BringToFront();

            // Muestra el formulario FrmEnvioADMIN
            frmEnvioADMIN.Show();
        }
    }
}
